package com.AndreyKrasnov.tfcores;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;

public class PipeVeinFeature extends ClusterVeinFeature {
    public PipeVeinFeature(Codec<CustomVeinConfig> codec) { super(codec); }

    @Override
    public boolean place(FeaturePlaceContext<CustomVeinConfig> context) {
        WorldGenLevel level = context.level();
        CustomVeinConfig config = context.config();
        RandomSource random = context.random();

        float baseRadius = config.radius();
        int depth = config.height();
        boolean placedAny = false;

        // Отслеживаем точный центр трубы в виде чисел с плавающей точкой
        float exactX = context.origin().getX();
        float exactY = context.origin().getY();
        float exactZ = context.origin().getZ();

        for (int y = 0; y < depth; y++) {
            float depthProgress = (float) y / depth;
            float currentRadius = baseRadius * (1.0f - (config.tapering() * depthProgress));
            if (currentRadius < 1.0f) currentRadius = 1.0f;

            int intRad = (int) Math.ceil(currentRadius);

            for (int x = -intRad - 2; x <= intRad + 2; x++) {
                for (int z = -intRad - 2; z <= intRad + 2; z++) {

                    float jitterX = x + (random.nextFloat() - 0.5f) * config.deformation();
                    float jitterZ = z + (random.nextFloat() - 0.5f) * config.deformation();

                    float distSq = jitterX * jitterX + jitterZ * jitterZ;

                    if (distSq <= currentRadius * currentRadius) {
                        if (random.nextFloat() <= config.density()) {
                            // Формируем позицию от точного центра
                            BlockPos targetPos = new BlockPos((int)exactX + x, (int)exactY - y, (int)exactZ + z);

                            if (distSq <= (currentRadius * 0.4f) * (currentRadius * 0.4f) && !config.richTargets().isEmpty()) {
                                if (tryPlaceOre(level, random, config.richTargets(), targetPos)) placedAny = true;
                            } else {
                                if (tryPlaceOre(level, random, config.targets(), targetPos)) placedAny = true;
                            }
                        }
                    }
                }
            }

            // Плавное блуждание (без эффекта квадратичного ускорения)
            exactX += (random.nextFloat() - 0.5f) * config.drift();
            exactZ += (random.nextFloat() - 0.5f) * config.drift();
        }
        return placedAny;
    }
}