package com.AndreyKrasnov.tfcores;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.heightproviders.HeightProviderType;
import net.minecraft.world.level.levelgen.placement.PlacementModifierType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.function.Supplier;

public class ModRegistries {
    public static final DeferredRegister<Feature<?>> FEATURES = DeferredRegister.create(BuiltInRegistries.FEATURE, TFCOres.MOD_ID);
    public static final DeferredRegister<HeightProviderType<?>> HEIGHT_PROVIDERS = DeferredRegister.create(BuiltInRegistries.HEIGHT_PROVIDER_TYPE, TFCOres.MOD_ID);
    public static final DeferredRegister<PlacementModifierType<?>> PLACEMENT_MODIFIERS = DeferredRegister.create(BuiltInRegistries.PLACEMENT_MODIFIER_TYPE, TFCOres.MOD_ID);

    public static final Supplier<Feature<CustomVeinConfig>> CLUSTER_VEIN = FEATURES.register("cluster_vein", () -> new ClusterVeinFeature(CustomVeinConfig.CODEC));
    public static final Supplier<Feature<CustomVeinConfig>> PIPE_VEIN = FEATURES.register("pipe_vein", () -> new PipeVeinFeature(CustomVeinConfig.CODEC));

    public static final Supplier<HeightProviderType<NormalizedHeightProvider>> NORMALIZED_HEIGHT = HEIGHT_PROVIDERS.register("normalized", () -> () -> NormalizedHeightProvider.CODEC);
    public static final Supplier<PlacementModifierType<TemperatureFilterModifier>> TEMPERATURE_FILTER = PLACEMENT_MODIFIERS.register("temperature_filter", () -> () -> TemperatureFilterModifier.CODEC);

    public static void register(IEventBus bus) {
        FEATURES.register(bus);
        HEIGHT_PROVIDERS.register(bus);
        PLACEMENT_MODIFIERS.register(bus);
    }
}