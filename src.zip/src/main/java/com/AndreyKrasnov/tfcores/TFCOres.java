package com.AndreyKrasnov.tfcores;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(TFCOres.MOD_ID)
public class TFCOres {
    public static final String MOD_ID = "tfcores";
    public TFCOres(IEventBus modEventBus) {
        ModRegistries.register(modEventBus);
    }
}