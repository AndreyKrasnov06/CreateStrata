package com.AndreyKrasnov.tfcores;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;

import java.util.ArrayList;
import java.util.List;

public class ClusterVeinFeature extends Feature<CustomVeinConfig> {
    public ClusterVeinFeature(Codec<CustomVeinConfig> codec) { super(codec); }

    private record Node(float x, float y, float z, float radius) {}

    @Override
    public boolean place(FeaturePlaceContext<CustomVeinConfig> context) {
        WorldGenLevel level = context.level();
        BlockPos origin = context.origin();
        CustomVeinConfig config = context.config();
        RandomSource random = context.random();

        int radius = config.radius();
        int height = config.height();
        boolean placedAny = false;

        int nodeCount = 4 + random.nextInt(4);
        List<Node> nodes = new ArrayList<>();
        for (int i = 0; i < nodeCount; i++) {
            float nx = (random.nextFloat() * 2 - 1) * (radius * 0.5f);
            float ny = (random.nextFloat() * 2 - 1) * (height * 0.5f);
            float nz = (random.nextFloat() * 2 - 1) * (radius * 0.5f);
            float nRadius = radius * (0.4f + 0.6f * random.nextFloat());
            nodes.add(new Node(nx, ny, nz, nRadius));
        }

        // РАСШИРЕННАЯ РАМКА: умножаем на 1.6, чтобы не обрезать края и избежать кубов
        int boxRadius = (int) (radius * 1.6f);
        int boxHeight = (int) (height * 1.6f);

        for (int x = -boxRadius; x <= boxRadius; x++) {
            for (int y = -boxHeight; y <= boxHeight; y++) {
                for (int z = -boxRadius; z <= boxRadius; z++) {

                    float jitterX = x + (random.nextFloat() - 0.5f) * config.deformation();
                    float jitterY = y + (random.nextFloat() - 0.5f) * config.deformation();
                    float jitterZ = z + (random.nextFloat() - 0.5f) * config.deformation();

                    float fieldDensity = 0;

                    for (Node node : nodes) {
                        float dx = jitterX - node.x;
                        float dy = jitterY - node.y;
                        float dz = jitterZ - node.z;

                        if (height < radius) {
                            dy *= ((float) radius / height); // Сплющивание в диск
                        }

                        float distSq = dx * dx + dy * dy + dz * dz;
                        if (distSq < 0.0001f) distSq = 0.0001f;
                        fieldDensity += (node.radius * node.radius) / distSq;
                    }

                    if (fieldDensity >= 1.0f) {
                        if (random.nextFloat() <= config.density()) {
                            BlockPos targetPos = origin.offset(x, y, z);

                            if (fieldDensity >= 2.5f && !config.richTargets().isEmpty()) {
                                if (tryPlaceOre(level, random, config.richTargets(), targetPos)) placedAny = true;
                            } else {
                                if (tryPlaceOre(level, random, config.targets(), targetPos)) placedAny = true;
                            }
                        }
                    }
                }
            }
        }
        return placedAny;
    }

    protected boolean tryPlaceOre(WorldGenLevel level, RandomSource random, List<OreConfiguration.TargetBlockState> targets, BlockPos pos) {
        // ПРЕДОХРАНИТЕЛЬ: проверяем, загружен ли чанк (спасет от крашей при обрыве жил)
        if (!level.hasChunk(pos.getX() >> 4, pos.getZ() >> 4)) return false;

        BlockState currentState = level.getBlockState(pos);
        for (OreConfiguration.TargetBlockState target : targets) {
            if (target.target.test(currentState, random)) {
                level.setBlock(pos, target.state, 2);
                return true;
            }
        }
        return false;
    }
}