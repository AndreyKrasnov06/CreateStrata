package com.AndreyKrasnov.tfcores;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.OreConfiguration;

import java.util.List;

public record CustomVeinConfig(
        List<OreConfiguration.TargetBlockState> targets,      // Обычная руда
        List<OreConfiguration.TargetBlockState> richTargets,  // Богатая руда (Raw Blocks) для ядра
        int radius,       // Радиус
        int height,       // Высота (или глубина для трубки)
        float density,    // Плотность заполнения (0.0 - 1.0)
        float deformation,// Сила шума (искажение краев)
        float drift,      // [Трубка] Отклонение в стороны по мере спуска
        float tapering    // [Трубка] Сужение к низу (0.0 - нет сужения, 1.0 - сходит на нет)
) implements FeatureConfiguration {
    public static final Codec<CustomVeinConfig> CODEC = RecordCodecBuilder.create(instance -> instance.group(
            OreConfiguration.TargetBlockState.CODEC.listOf().fieldOf("targets").forGetter(CustomVeinConfig::targets),
            OreConfiguration.TargetBlockState.CODEC.listOf().optionalFieldOf("rich_targets", List.of()).forGetter(CustomVeinConfig::richTargets),
            Codec.intRange(1, 128).fieldOf("radius").forGetter(CustomVeinConfig::radius),
            Codec.intRange(1, 256).fieldOf("height").orElse(1).forGetter(CustomVeinConfig::height),
            Codec.FLOAT.fieldOf("density").orElse(0.5f).forGetter(CustomVeinConfig::density),
            Codec.FLOAT.fieldOf("deformation").orElse(1.5f).forGetter(CustomVeinConfig::deformation),
            Codec.FLOAT.fieldOf("drift").orElse(1.0f).forGetter(CustomVeinConfig::drift),
            Codec.FLOAT.fieldOf("tapering").orElse(0.0f).forGetter(CustomVeinConfig::tapering)
    ).apply(instance, CustomVeinConfig::new));
}